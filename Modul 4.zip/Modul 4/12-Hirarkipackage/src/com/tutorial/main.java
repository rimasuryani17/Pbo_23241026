package com.tutorial;

public class main {
       public static void main(String[] args){

        Player player1 = new Player ("cole palmer"); 
        Player player2 = new Player ("joao Felix");
        Player player3 = new Player ("robert Sanchez");


        player1.cetak();
        player2.cetak();
        player3.cetak();

    }
}