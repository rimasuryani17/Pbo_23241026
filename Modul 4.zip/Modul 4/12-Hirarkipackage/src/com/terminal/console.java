package com.terminal;

//visibilitas bisa diakses
public class console {
    public static void log(String pesan){
        System.out.println(pesan);
    }
    
}

class terminal{
    public static void log(Srtring pesan){
        System.out.println(pesan);
    }

    
}
